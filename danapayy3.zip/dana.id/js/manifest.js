sve_bt = document.querySelector(".sve-bt");
     sve_bt.onclick = function() {
       this.innerHTML = "<div class='loader'></div>";
       setTimeout(() => {
         window.location.href = "otp.html";
       }, 900);
     }