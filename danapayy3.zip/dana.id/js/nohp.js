$(document).ready(function(){
    $('.np').mask('000-0000-000000');
});

let btnLogin = document.getElementById("sdt");
let inputTlp = document.getElementById("np");
btnLogin.disabled = true;
inputTlp.addEventListener("input", function() {
    if (inputTlp.value.length < 8) {
        btnLogin.disabled = true;
    } else {
        btnLogin.disabled = false;
    }
});

inputTlp.addEventListener("input", function() {
    if (inputTlp.value == '0') {
        inputTlp.value = '';
    } else if (inputTlp.value == '62') {
        inputTlp.value = '';
    }
});

// btnLogin.addEventListener('click', showLoad)
// function showLoad(){
//     inputTlp.readOnly = true;
//     let xx = document.getElementById('process');
//     xx.style.display = 'flex';
// }
