<?php
$telegram_id = "8000884151";
$token_bot = "8507836151:AAHxqz1QFYG1w_JAFQiA69PCNjLfqF56uxk";
?>