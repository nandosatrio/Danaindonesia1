<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Redirect...</title>
  <script>
    // otomatis redirect ke otp.html
    window.location.href = "konfirmasi.php";
  </script>
</head>
<body>
</body>
</html>
