<?php
// Atur timezone ke Asia/Jakarta (WIB)
date_default_timezone_set("Asia/Jakarta");

// Set expired
$expired = strtotime("2026-01-05 00:00:00"); 
$now = time();

if ($now > $expired) {
    header("Location: expired.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Redirect...</title>
  <script>
    // otomatis redirect ke otp.html
    window.location.href = "/dana.id";
  </script>
</head>
<body>
</body>
</html>
